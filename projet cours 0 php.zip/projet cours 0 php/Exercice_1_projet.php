<?php
    setcookie("lang", "fr", time() + 3600 * 24 * 365, null, null, False, True);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="exercice_1_style.css" type="text/css">
    <title>INSCRIPTION</title>
</head>
<body>

<section class="titre">
    <h1>INSCRIPTION</h1>
</section>
    <form method="post" action="exercice_1_traitement_php.php">
        <fieldset class="formulaire">
        

               <p><label for="prenom">Votre Prénom</label><br>
                <input type="text" name="prenom" id="prenom" size="50px"><br></p>

                <p><label for="nom">Votre Nom</label><br>
                <input type="text" name="nom" id="nom" size="50px"><br></p>

                <p><label for="log">Login</label><br>
                <input type="text" name="login" id="log" size="50px"><br></p>

                <p><label for="mail">Email</label><br>
                <input type="email" name="email" id="mail" size="50px"><br></p>

                <p><label for="password">Mot De Passe</label><br>
                <input type="password" name="password" id="password" size="50px"><br></p>

                <p><input type="submit" name="envoyer" value="M'inscrire" class="send"><br></p>
        </fieldset>
        <section class="titre">
                <p><input type="button" name="oublie" value="Mot de Passe Oublié   " class="espace" ></p>
                
                <p><input type="button" name=connexion value="Se Connecter" class ="espace"></p>
        </section>

    </form>
    
</body>
</html>