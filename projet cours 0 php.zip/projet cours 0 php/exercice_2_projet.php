<?php
    session_start();
    if(!session_id())
    {
        session_regenerate(True);
    }
    $_SESSION["prenom"] = $_POST["prenom"];
    $_SESSION["nom"] = $_POST["nom"];
    $_SESSION["login"] = $_POST["login"];
    $_SESSION["email"] = $_POST["email"];
    $_SESSION["password"] = $_POST["password"];
    function utilisateur(...$info)
    {
        foreach($info as $data)
        {
            echo("$data");
        }
    }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des utilisateurs</title>
    <link rel="stylesheet" href="exercice_2_style.css">
</head>
<body>
    <p><a href="Exercice_1_projet.php"> <h1 >Retour à L'inscription</h1></a></p>



    <table>

        <thead class="tete">
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Login</th>
                <th>Email</th>
            </tr>
        </thead>

        <tbody>

            <tr>
                <td><?php echo htmlspecialchars( $_SESSION["prenom"]); ?></td>
                <td><?php echo htmlspecialchars($_SESSION["nom"]); ?></td>
                <td><?php echo htmlspecialchars($_SESSION["login"]); ?></td>
                <td><?php echo htmlspecialchars($_SESSION["email"]); ?></td>
            </tr>

            <tr>
                <td><?php htmlspecialchars(utilisateur("Blaise")); ?></td>
                <td><?php htmlspecialchars(utilisateur("NDIAYE")); ?></td>
                <td><?php htmlspecialchars(utilisateur("blaisendiaye01")); ?></td>
                <td><?php htmlspecialchars(utilisateur("blaisendiaye@gmail.com")); ?></td>
            </tr>


            <tr>
                <td><?php  htmlspecialchars(utilisateur("Mohammed")); ?></td>
                <td><?php htmlspecialchars(utilisateur("BA")); ?></td>
                <td><?php htmlspecialchars(utilisateur("mohammedba")); ?></td>
                <td><?php htmlspecialchars(utilisateur("mohammedba@gmail.com")); ?></td>
            </tr>

        </tbody>


    </table>
</body>
</html>
<?php

    session_unset();
    session_destroy();

?>





















