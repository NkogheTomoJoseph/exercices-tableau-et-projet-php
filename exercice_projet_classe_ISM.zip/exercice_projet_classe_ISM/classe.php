<?php
    session_start();
    if(!session_id()){
        session_regenerate_id();
        session_start();
    }

    $_SESSION["niveaux"] = ["L1","L2","L3"];

    $_SESSION["classes"] = [
                    ["niveau"=>"L1", "filiere"=>"MAIE",
                        "etudiants"=> [
                            ["nom"=>"NDIAYE", "prenom"=>"Babacar", "naiss"=>"30/12/1999", "sexe"=>"M"],
                            ["nom"=>"DIOP", "prenom"=>"Daba", "naiss"=>"28/02/2000", "sexe"=>"M"],
                            ["nom"=>"FALL", "prenom"=>"Maciya", "naiss"=>"12/01/2001", "sexe"=>"F"],
                            ["nom"=>"DIOUF", "prenom"=>"Keeba", "naiss"=>"10/05/1999", "sexe"=>"M"],
                            ["nom"=>"GUEYE", "prenom"=>"Mati", "naiss"=>"10/06/2000", "sexe"=>"F"],
                        ]
                    
                        ],


                    ["niveau"=>"L1", "filiere"=>"GLRS",
                        "etudiants"=>[
                            ["nom"=>"FAYE", "prenom"=>"Babacar", "naiss"=>"20/12/2000", "sexe"=>"F"],
                            ["nom"=>"DIALLO", "prenom"=>"Daba", "naiss"=>"25/05/2001", "sexe"=>"M"],
                            ["nom"=>" BA", "prenom"=>"Maciya", "naiss"=>"30/01/2002", "sexe"=>"F"],
                            ["nom"=>"SARR", "prenom"=>"Keeba", "naiss"=>"10/05/1999", "sexe"=>"F"],
                            ["nom"=>"SOW", "prenom"=>"Mati", "naiss"=>"10/06/2001", "sexe"=>"F"],
                        ]
                    
                        ],

                    ["niveau"=>"L1", "filiere"=>"TTL",
                        "etudiants"=>[
                            ["nom"=>"SECK", "prenom"=>"Fatou", "naiss"=>"20/12/2001", "sexe"=>"F"],
                            ["nom"=>"NIANG", "prenom"=>"Ibrahima", "naiss"=>"25/05/2001", "sexe"=>"M"],
                            ["nom"=>"DIAGNE", "prenom"=>"Awa", "naiss"=>"30/01/2000", "sexe"=>"F"],
                            ["nom"=>"MBAYE", "prenom"=>"Khady", "naiss"=>"10/05/1999", "sexe"=>"F"],
                            ["nom"=>"THIAM", "prenom"=>"Coumba", "naiss"=>"10/06/1998", "sexe"=>"F"],
                        ]
                    
                        ],


                    ["niveau"=>"L2", "filiere"=>"MAIE",
                    "etudiants"=>[
                        ["nom"=>"KANE", "prenom"=>"Aminata", "naiss"=>"20/12/2001", "sexe"=>"F"],
                        ["nom"=>"DRAME", "prenom"=>"Assiatou", "naiss"=>"25/05/2001", "sexe"=>"M"],
                        ["nom"=>"SANE", "prenom"=>"Mariama", "naiss"=>"30/01/2000", "sexe"=>"F"],
                        ["nom"=>"DIAW", "prenom"=>"Maimouna", "naiss"=>"10/05/2001", "sexe"=>"F"],
                        ["nom"=>"SYLLA", "prenom"=>"Rokhaya", "naiss"=>"10/06/1999", "sexe"=>"F"],
                    ]
            
                    ],


                    ["niveau"=>"L2", "filiere"=>"GLRS",
                        "etudiants"=>[
                            ["nom"=>"FAYE", "prenom"=>"Babacar", "naiss"=>"20/12/2000", "sexe"=>"F"],
                            ["nom"=>"DIALLO", "prenom"=>"Daba", "naiss"=>"25/05/2001", "sexe"=>"M"],
                            ["nom"=>" BA", "prenom"=>"Maciya", "naiss"=>"30/01/2002", "sexe"=>"F"],
                            ["nom"=>"SARR", "prenom"=>"Keeba", "naiss"=>"10/05/1999", "sexe"=>"F"],
                            ["nom"=>"SOW", "prenom"=>"Mati", "naiss"=>"10/06/2001", "sexe"=>"F"],
                        ]
                    
                        ],

                    ["niveau"=>"L2", "filiere"=>"TTL",
                        "etudiants"=>[
                            ["nom"=>"SECK", "prenom"=>"Fatou", "naiss"=>"20/12/2001", "sexe"=>"F"],
                            ["nom"=>"NIANG", "prenom"=>"Ibrahima", "naiss"=>"25/05/2001", "sexe"=>"M"],
                            ["nom"=>"DIAGNE", "prenom"=>"Awa", "naiss"=>"30/01/2000", "sexe"=>"F"],
                            ["nom"=>"MBAYE", "prenom"=>"Khady", "naiss"=>"10/05/1999", "sexe"=>"F"],
                            ["nom"=>"THIAM", "prenom"=>"Coumba", "naiss"=>"10/06/1998", "sexe"=>"F"],
                        ]
                    
                        ],




                    ["niveau"=>"L3", "filiere"=>"MAIE",
                        "etudiants"=>[
                            ["nom"=>"NDIAYE", "prenom"=>"Babacar", "naiss"=>"30/12/1996", "sexe"=>"M"],
                            ["nom"=>"DIOP", "prenom"=>"Daba", "naiss"=>"28/02/1998", "sexe"=>"M"],
                            ["nom"=>"FALL", "prenom"=>"Maciya", "naiss"=>"15/04/1997", "sexe"=>"F"],
                            ["nom"=>"DIOUF", "prenom"=>"Keeba", "naiss"=>"25/07/1998", "sexe"=>"M"],
                            ["nom"=>"GUEYE", "prenom"=>"Mati", "naiss"=>"27/03/1996", "sexe"=>"F"],
                        ]
                
                        ],

                    ["niveau"=>"L3", "filiere"=>"GLRS",
                        "etudiants"=>[
                            ["nom"=>"FAYE", "prenom"=>"Babacar", "naiss"=>"09/01/1995", "sexe"=>"F"],
                            ["nom"=>"DIALLO", "prenom"=>"Daba", "naiss"=>"25/12/1995", "sexe"=>"M"],
                            ["nom"=>" BA", "prenom"=>"Maciya", "naiss"=>"30/04/1998", "sexe"=>"F"],
                            ["nom"=>"SARR", "prenom"=>"Keeba", "naiss"=>"16/04/1996", "sexe"=>"F"],
                            ["nom"=>"SOW", "prenom"=>"Mati", "naiss"=>"12/11/1998", "sexe"=>"F"],
                        ]
                    
                        ],

                    ["niveau"=>"L3", "filiere"=>"TTL",
                        "etudiants"=>[
                            ["nom"=>"SECK", "prenom"=>"Fatou", "naiss"=>"25/12/1995", "sexe"=>"F"],
                            ["nom"=>"NIANG", "prenom"=>"Ibrahima", "naiss"=>"12/11/1998", "sexe"=>"M"],
                            ["nom"=>"DIAGNE", "prenom"=>"Awa", "naiss"=>"16/04/1996", "sexe"=>"F"],
                            ["nom"=>"MBAYE", "prenom"=>"Khady", "naiss"=>"30/04/1998", "sexe"=>"F"],
                            ["nom"=>"THIAM", "prenom"=>"Coumba", "naiss"=>"09/01/1995", "sexe"=>"F"],
                        ]
                    
                        ]

                        
            ];


            
            

  
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche de classe</title>
</head>
<body>

    <form action="etudiant.php" method="POST">


        <p>
            <label for="niveau">Niveau</label>
            <select name="niveau" id="niveau" size="1">

                <option value="L1">Licence 1</option>
                <option value="L2">Licence 2</option>
                <option value="L3">Licence 3</option>

            </select>
    
        

        

            <label for="filiere">Filière</label>
            <select name="filiere" id="filiere" size="1">

                <option value="maie">MAIE</option>
                <option value="glrs">GLRS</option>
                <option value="ttl">TTL</option>
                <option value="liage">LIAGE</option>

            </select>

        

        
            <input type="submit" name="ok" value="OK">
        </P>


    </form>

    <table>

            <thead>

                <th>Niveau</th>
                <th>Filière</th>
                <th>Actions</th>

            </thead>

            <tbody>

                <?php foreach ($_SESSION["classes"] as $key=> $classe): 
                     foreach($classe as $cle=> $info):?>     

                        <tr>
                                <td>
                                    <?php 
                                        if($cle=="niveau"){
                                            echo $info;
                                        }
                                    ?> 
                                </td>

                                <td>
                                    <?php 
                                        if ($cle=="filiere") {
                                            echo $info;
                                        }
                                    ?>                    
                                </td>

                                <td>
                                    <a href="etudiant.php">
                                        <?php
                                            if($cle=="etudiants"):
                                                echo "$cle";
                                            endif
                                        ?>
                                    </a>
                                </td>

                        </tr><br>
                    <?php endforeach?>
                <?php endforeach ?>
                
                
            </tbody>




    </table>





    
</body>
</html>