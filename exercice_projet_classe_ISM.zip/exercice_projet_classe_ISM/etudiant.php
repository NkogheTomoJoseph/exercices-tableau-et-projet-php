<?php
 session_start();
 if(!session_id()){
    session_regenerate_id();
    session_start(); 
 }

 foreach ($_SESSION["classes"] as $classe) {
     echo $classe["membres"] ;
 }

foreach ($_SESSION["classes"] as $classe) {
    echo $classe["liste"];
}

?>