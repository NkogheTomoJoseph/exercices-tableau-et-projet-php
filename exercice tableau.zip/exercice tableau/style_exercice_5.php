<?php


header ("content-type: text/css; charset:UTF-8");
$tableau_couleurs = ["blue", "red", "yellow", "green", "orange"];
$couleur_ligne_1 = $tableau_couleurs[0];
$couleur_ligne_2 = $tableau_couleurs[1];
$couleur_ligne_3 = $tableau_couleurs[2];
$couleur_ligne_4 = $tableau_couleurs[3];
$couleur_ligne_5 = $tableau_couleurs[4];

?>

::before, ::after {

    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    height: 100vh;
    font-family: Arial, Helvetica, sans-serif;
}
.tableau_style{
    border-collapse:collapse;
    min-width: 400px;
    width: auto;
    box-shadow: 0 5px 50px rgba(0, 0, 0,);
    margin: 100px auto;
    border: 2px solid black;
}

tbody tr {

    text-align: center;
    
}
.ligne_1{
    background-color: <?= $couleur_ligne_1?>;
}

.ligne_2{
    background-color: <?= $couleur_ligne_2?>;
}

.ligne_3{
    background-color: <?= $couleur_ligne_3?>;
}

.ligne_4{
    background-color: <?= $couleur_ligne_4?>;
}

.ligne_5{
    background-color: <?= $couleur_ligne_5?>;

}
td{
    padding: 15px 20px;
}

td, tr{
    border: 2px solid black
}
