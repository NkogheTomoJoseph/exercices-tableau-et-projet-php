<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercice 5</title>
    <link rel="stylesheet" href="style_exercice_5.php" type="text/css">
</head>
<body>



<table class ="tableau_style">
    <tbody>
        <tr class ="ligne_1">
            <td>couleur 0</td>
            <td>couleur 0</td>

        </tr>

        <tr class = "ligne_2">
            <td>couleur 1</td>
            <td>couleur 1</td>
            
        </tr>


        <tr class = "ligne_3">
            <td>couleur 2</td>
            <td>couleur 2</td>
            
        </tr>


        <tr class = "ligne_4">
            <td>couleur 3</td>
            <td>couleur 3</td>
            
        </tr>


        <tr class = "ligne_5">
            <td>couleur 4</td>
            <td>couleur 4</td>
            
        </tr>
    </tbody>
</table>




