<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercice 6</title>
</head>
<body>
<table>

    <tr>
        <td></td>
    </tr>

    <tr>
        <td></td>
    </tr>

    <tr>
        <td></td>
    </tr>

    <tr>
        <td></td>
    </tr>


    <tr>
        <td></td>
    </tr>


    <tr>
        <td></td>
    </tr>


</table>
    
    <?php


        /*
        Exerciec 7

        Ecrire un script qui nitialise un tableau d'entier, puis génère une table html dont le nombre
        de ligne est égal aux nombre d'éléments du tableau.
        Le nombre de colonne de chaque ligne correspond respectivement à la valeur se trouvant dans 
        le tableau d'entier
        */


        $tableau = [2, 4, 5, 1, 6, 3];




    ?>  
</body>
</html>