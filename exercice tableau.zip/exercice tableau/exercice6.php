<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercice 6</title>
</head>
<body>



    <?php

    /*
    Exercice 6

    Ecrire un script qui initialise un tableau de classe
    le script génère des listes (ul) (li) des classes par niveau

    */
    $tableau = ["Sénégal"=> 17*(10**6),

                "Bénin"=> 13*(10**6), 

                "Togo"=> 9*(10**6),

                "Burkina Faso"=> 21*(10**6), 

                "Mali"=>21*(10**6)
    ];
    foreach($tableau as $pays=>$population){

        echo("<ul>
                <li>le $pays continet une population de $population d'habitants.</li>
            </ul>");
           
        
    }
    ?>

<li></li>





</body>
</html>