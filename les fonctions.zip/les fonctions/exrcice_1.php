<?php

    /*
    somme de 2 nombres, 3 nombres, 4 nombres
    */

    //Definition
    function somme(int($val1), int($val2), int($val3=0), int($val4=0)):int{

        return($val1+$val2+$val3+$val4);
    }

    //Appels

    $result1 = somme(3,5);
    $result2  = somme(3,5,$result1)

    /*
        ecrire un scrip qui définie les fonctions suivantes:
        une fonction qui ninitialise un tableau d'entiers;
        une fonction qui affiche un tableau d'entiers;
        une fonction qui verifie si un element est present dans un tableau ou pas;
        une fonction qui transfère dans un tableau t1 les valeurs pairs et dans un tableau t2 les valeurs impairs d'un tableau passé en paramètre;
        les tableaux t1 et t2 sont affichés;
        une fonction qui trie le tableau suivant un ordre passé en paramètre(croissant, décroissant);
        une fonction qui détermine les deux plus grandes valeurs du tableau et les deux plus petites valeurs du tableau.
    */


?>