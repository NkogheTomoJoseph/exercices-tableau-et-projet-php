<?php

/*
        ecrire un scrip qui définie les fonctions suivantes:
        une fonction qui ninitialise un tableau d'entiers;
        une fonction qui affiche un tableau d'entiers;
        une fonction qui verifie si un element est present dans un tableau ou pas;
        une fonction qui transfère dans un tableau t1 les valeurs pairs et dans un tableau t2 les valeurs impairs d'un tableau passé en paramètre;
        les tableaux t1 et t2 sont affichés;
        une fonction qui trie le tableau suivant un ordre passé en paramètre(croissant, décroissant);
        une fonction qui détermine les deux plus grandes valeurs du tableau et les deux plus petites valeurs du tableau.
    */

    function init_tableau(int $taille):array{
        $tab=array();
       for($i=0;$i<=$taille;$i++){
           $tab[$i]=rand(-100,100);
       }
       return $tab;
   }
   
   function afficher(array $input):void{
       foreach($input as $element){
           echo "$element ";
       }
       echo("<br>");
   }
   
   function presence(array $input,int $element):bool{
       return in_array($element,$input);
   }
   
   function parite(array $input):void{
       $pair=array();
       $impair=array();
       foreach($input as $elmt){
           if($elmt%2==0){
               array_push($pair,$elmt);
           }
           else{
               array_push($impair,$elmt);
           }
       }
       afficher($pair);
       afficher($impair);
   }
   
   function trie(string $ordre,array $input):void{
       if($ordre=="croissant"){
           asort($input);
       }
       if($ordre=="decroissant"){
           arsort($input);
       }
   }
   
   function valeurOrdonnee(array $input):void{
       trie("croissant",$input);
       echo("les 2 plus petites valeurs sont : $input[0] $input[1] <br>");
   
       trie("decroissant",$input);
       echo("les 2 plus grandes valeurs sont : $input[0] $input[1] <br>");
   }
   
   $tab=array();
   $tab=init_tableau(8);
   afficher($tab);
   parite($tab);
   valeurOrdonnee($tab);
   ?>
